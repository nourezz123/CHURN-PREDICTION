import numpy as np
import scipy.stats as stats

def summarize_by_churn_risk_score(data):
    # Function to calculate the Interquartile Range (IQR)
    def iqr(x):
        return np.percentile(x, 75) - np.percentile(x, 25)

    # Select only numerical variables (excluding churn_risk_score itself from the analysis)
    num_cols = data.select_dtypes(include=[np.number]).columns.tolist()
    num_cols = [col for col in num_cols if col != 'churn_risk_score']

    # Compute the required statistics for each group based on churn_risk_score
    summary = data.groupby('churn_risk_score')[num_cols].agg(['mean', 'std', 'median', 'count', iqr])

    return summary

from feature_engineering import perform_feature_engineering
from cleaning_preprocessing import preprocess_data ,clean_data
from ML import svm_model, SVM_after_tuning , LogisticRegression_model , LogisticRegression_tuning , lg_model, lg_model_tuning , lg_better_thresholds , knn_model, knn_model_tuning
import pandas as pd
import numpy as np
from EDA import Histograms, Boxplot, heatmap, Pairplot
from sklearn.preprocessing import MinMaxScaler




df= pd.read_csv('churn.csv')
data= df.copy()
cleaned_data = clean_data(data)
preprocessed_data= preprocess_data(data)
engineed_data= perform_feature_engineering(preprocessed_data)
svm_model()
# Import required libraries
from sklearn.model_selection import train_test_split , GridSearchCV
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from feature_engineering import perform_feature_engineering
from cleaning_preprocessing import preprocess_data ,clean_data
import pandas as pd
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import uniform
import numpy as np
from sklearn.linear_model import LogisticRegression
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from skopt import BayesSearchCV  # Library for Bayesian Optimization
from sklearn.neighbors import KNeighborsClassifier
import warnings

df= pd.read_csv('churn.csv')
data= df.copy()
preprocessed_data= preprocess_data(data)
engineered_data= perform_feature_engineering(preprocessed_data)
# Features that are common between Random Forest and Logistic Regression
common_features = [
    'membership_category(Basic Membership)', 'feedback(Products always in Stock)',
    'membership_category(No Membership)', 'log_customer_tenure',
    'feedback(Quality Customer Care)', 'feedback(Reasonable Price)',
    'log_points_in_wallet', 'membership_category(Silver Membership)',
    'feedback(User Friendly Website)', 'membership_category(Gold Membership)',
    'membership_category(Platinum Membership)', 'membership_category(Premium Membership)'
]

# Use only the common features from the dataset
data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()


def svm_model():
  # Split the data into features (X) and target (y)
  X = data_for_model_common.drop('churn_risk_score', axis=1)
  y = data_for_model_common['churn_risk_score']
  # Split the data into training and testing sets
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

  # Create an SVM model with a linear kernel using StandardScaler in a pipeline
  svm_model = make_pipeline(StandardScaler(), SVC(kernel='linear', random_state=42))

  # Train the model
  svm_model.fit(X_train, y_train)

  # Predict on the test set
  y_pred = svm_model.predict(X_test)

  # Evaluate the model
  print("🎯 Evaluation of SVM Model (Linear Kernel):")
  print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
  print("\nClassification Report:")
  print(classification_report(y_test, y_pred))

def  SVM_after_tuning():
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    pipeline = make_pipeline(StandardScaler(), SVC(probability=True, random_state=42))

    param_dist = {
        'svc__C': uniform(0.1, 10),             
        'svc__gamma': ['scale', 'auto'],
        'svc__kernel': ['linear', 'rbf'],       
    }

    random_search = RandomizedSearchCV(
        pipeline, param_distributions=param_dist,
        n_iter=10,  
        cv=3,       
        verbose=1,
        n_jobs=-1,
        random_state=42
    )
    random_search.fit(X_train, y_train)

    print("✅ Best Parameters:", random_search.best_params_)
    print(f"✅ Best CV Score: {random_search.best_score_:.4f}")

    y_pred_svm = random_search.predict(X_test)
    print("\n🎯 Evaluation on Test Set:")
    print(f"Accuracy: {accuracy_score(y_test, y_pred_svm):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_svm))


def LogisticRegression_model():
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()

    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    lr_model = LogisticRegression(solver='liblinear', random_state=42)

    lr_model.fit(X_train, y_train)

    y_pred = lr_model.predict(X_test)

    print("🎯 Evaluation of Logistic Regression Model:")
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

def LogisticRegression_tuning():
    # Use only the common features from the dataset
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()

    # Split the data into features (X) and target (y)
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create a Logistic Regression model with StandardScaler in a pipeline
    lr_model = make_pipeline(StandardScaler(), LogisticRegression(solver='liblinear', random_state=42))

    # Define the parameter space for Bayesian Optimization
    param_space = {
        'logisticregression__C': (1e-6, 1e+6, 'log-uniform'),  # C range in logarithmic scale
        'logisticregression__penalty': ['l1', 'l2'],  # Try both l1 and l2 penalties
        'logisticregression__max_iter': (100, 1000),  # Range for max_iter
        'logisticregression__class_weight': [None, 'balanced']  # Try both with and without class weighting
    }

    # Use BayesSearchCV to search for the best hyperparameters using Bayesian Optimization
    bayes_search = BayesSearchCV(
        lr_model,
        param_space,
        n_iter=50,
        cv=10,
        scoring='accuracy',
        n_jobs=-1,
        random_state=42,
        verbose=1
    )

    # Train the model using Bayesian Optimization
    bayes_search.fit(X_train, y_train)

    # Get the best estimator after tuning
    best_lr_model = bayes_search.best_estimator_

    # Predict on the test set
    y_pred_lr = best_lr_model.predict(X_test)

    # Evaluate the model
    print("🎯 Evaluation of Tuned Logistic Regression Model (Bayesian Optimization):")
    print(f"Accuracy: {accuracy_score(y_test, y_pred_lr):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_lr))

    # Display the best parameters found
    print("🎯 Best Parameters found by Bayesian Optimization:")
    print(bayes_search.best_params_)


def  lg_model():
    # Use only the common features from the dataset
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()

    # Split the data into features (X) and target (y)
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']
    X_train_full, X_test, y_train_full, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train, X_valid, y_train, y_valid = train_test_split(X_train_full, y_train_full, test_size=0.2, random_state=42)

    lgbm_model = LGBMClassifier(
        n_estimators=5000,
        learning_rate=0.05,
        random_state=42
    )

    lgbm_model.fit(
        X_train, y_train,
        eval_set=[(X_valid, y_valid)],
        callbacks=[early_stopping(stopping_rounds=10), log_evaluation(0)]
    )

    y_pred = lgbm_model.predict(X_test)

    print(" Evaluation of LightGBM Model (with Early Stopping using callbacks):")
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

def lg_model_tuning():
    # Use only the common features from the dataset
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()
    # Split the data into features (X) and target (y)
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']    
    # Split the data into training, testing, and validation sets
    X_train_full, X_test, y_train_full, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train, X_valid, y_train, y_valid = train_test_split(X_train_full, y_train_full, test_size=0.2, random_state=42)

    # Define the LightGBM model with class_weight to emphasize class 1 (positive class)
    lgbm_model = LGBMClassifier(
        n_estimators=1000,
        learning_rate=0.05,
        max_depth=7,
        num_leaves=31,
        reg_alpha=0.1,
        reg_lambda=1.0,
        min_child_samples=30,
        eval_metric='logloss',
        class_weight='balanced',  # ✅ Automatically balances the classes
        random_state=42
    )

    # Train the model with early stopping and logging
    lgbm_model.fit(
        X_train, y_train,
        eval_set=[(X_valid, y_valid)],
        callbacks=[early_stopping(stopping_rounds=20), log_evaluation(100)]
    )

    # 📌 Evaluation using the default threshold (0.5)
    y_pred_default = lgbm_model.predict(X_test)
    print("📊 Evaluation with Default Threshold (0.5):")
    print(f"Accuracy: {accuracy_score(y_test, y_pred_default):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_default))

    # 📌 Evaluation using a custom threshold (e.g., 0.4)
    y_probs = lgbm_model.predict_proba(X_test)[:, 1]
    threshold = 0.4
    y_pred_thresh = np.where(y_probs >= threshold, 1, 0)

    print(f"\n📊 Evaluation with Custom Threshold = {threshold}:")
    print(f"Accuracy: {accuracy_score(y_test, y_pred_thresh):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_thresh))

def lg_better_thresholds():
    # Use only the common features from the dataset
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()
    # Split the data into features (X) and target (y)
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']   
    # Split the dataset
    X_train_full, X_test, y_train_full, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train, X_valid, y_train, y_valid = train_test_split(X_train_full, y_train_full, test_size=0.2, random_state=42)

    # Initialize LightGBM model
    lgbm_model = LGBMClassifier(
        n_estimators=1000,
        learning_rate=0.05,
        max_depth=7,
        num_leaves=31,
        reg_alpha=0.1,
        reg_lambda=1.0,
        min_child_samples=30,
        random_state=42
    )

    # Train the model with early stopping
    lgbm_model.fit(
        X_train, y_train,
        eval_set=[(X_valid, y_valid)],
        callbacks=[early_stopping(stopping_rounds=20), log_evaluation(100)]
    )

    # Predict probabilities
    y_proba = lgbm_model.predict_proba(X_test)[:, 1]

    # Apply custom threshold
    threshold = 0.4
    y_pred_lg= (y_proba >= threshold).astype(int)

    # Evaluate
    print(f"📊 Evaluation with Custom Threshold = {threshold}:")
    print(f"Accuracy: {accuracy_score(y_test, y_pred_lg):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred_lg))


def knn_model():
    warnings.filterwarnings('ignore')
    data_for_model_common = engineered_data[common_features + ['churn_risk_score']].copy()
    # Split the data into features (X) and target (y)
    X = data_for_model_common.drop('churn_risk_score', axis=1)
    y = data_for_model_common['churn_risk_score']   

    X_selected = X[common_features]
    y_selected = y


    X_train, X_test, y_train, y_test = train_test_split(X_selected, y_selected, test_size=0.2, random_state=42)


    knn_model = KNeighborsClassifier(n_neighbors=5)


    knn_model.fit(X_train, y_train)

    y_pred = knn_model.predict(X_test)

    print("📊 Evaluation of K-Nearest Neighbors Classifier:")
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))  
    return X,y, y_pred 

def knn_model_tuning():
    X, y, y_pred = knn()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    param_grid = {
        'n_neighbors': [3, 5, 7, 9, 11, 13,15, 17, 19, 21, 31, 41, 45, 61],
        'weights': ['uniform', 'distance'],
        'metric': ['euclidean', 'manhattan']
    }


    knn = KNeighborsClassifier()

    grid_search = GridSearchCV(knn, param_grid, cv=5, scoring='recall', n_jobs=-1)
    grid_search.fit(X_train, y_train)

    best_knn = grid_search.best_estimator_

    y_pred_knn = best_knn.predict(X_test)

    print(" Best Parameters:", grid_search.best_params_)
    print("Best CV Score:", grid_search.best_score_)
    print("Accuracy on Test Set:", accuracy_score(y_test, y_pred))
    print("\n Classification Report:")
    print(classification_report(y_test, y_pred))


